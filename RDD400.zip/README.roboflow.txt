
RDD - v3 RDD400
==============================

This dataset was exported via roboflow.ai on May 30, 2021 at 11:12 AM GMT

It includes 314 images.
RDD are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 400x400 (Stretch)

No image augmentation techniques were applied.


